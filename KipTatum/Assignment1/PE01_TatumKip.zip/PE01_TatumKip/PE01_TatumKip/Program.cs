﻿using System;

namespace PE01_TatumKip
{
	class Program
	{
		/********
		**
		**Name: Tatum, Kip
		**Class: CS 132
		**Project: 01
		**Date: 2020-10-08
		**Description: This is a simple Hello World program.  The output will
		**be a console window that displays "Hello World"
		*********/
		static void Main(string[] args)
		{
			//not really sure what to comment this is pretty straight forward
			string output = "Hello World";
			Console.WriteLine(output);
			Console.ReadLine();
		}
	}
}
